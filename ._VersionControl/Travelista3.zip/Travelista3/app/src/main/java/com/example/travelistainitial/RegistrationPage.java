package com.example.travelistainitial;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RegistrationPage extends AppCompatActivity {

    TextInputLayout layoutRegName, layoutRegEmail, layoutRegContactNumber, layoutRegPassword1, layoutRegPassword2;

    TextInputEditText edtRegName, edtRegEmail, edtRegContactNumber, edtRegPassword1, edtRegPassword2;

    Button btnCreate;

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://useful-maxim-382603-default-rtdb.firebaseio.com/");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        layoutRegName = findViewById(R.id.layoutRegName);
        layoutRegEmail = findViewById(R.id.layoutRegEmail);
        layoutRegContactNumber = findViewById(R.id.layoutRegContactNumber);
        layoutRegPassword1 = findViewById(R.id.layoutRegPassword1);
        layoutRegPassword2 = findViewById(R.id.layoutRegPassword2);

        edtRegName = findViewById(R.id.edtRegName);
        edtRegEmail = findViewById(R.id.edtRegEmail);
        edtRegContactNumber = findViewById(R.id.edtRegContactNumber);
        edtRegPassword1 = findViewById(R.id.edtRegPassword1);
        edtRegPassword2 = findViewById(R.id.edtRegPassword2);

        btnCreate = findViewById(R.id.btnCreate);


        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edtRegName.getText().toString();
                String email = edtRegEmail.getText().toString();
                String contact = edtRegContactNumber.getText().toString();
                String password1 = edtRegPassword1.getText().toString();
                String password2 = edtRegPassword2.getText().toString();

                if (name.isEmpty() || email.isEmpty() || contact.isEmpty() || password1.isEmpty() || password2.isEmpty()) {
                    Toast.makeText(RegistrationPage.this, "Please complete all fields.", Toast.LENGTH_SHORT).show();
                }

                else if (!password1.equals(password2)) {
                    Toast.makeText(RegistrationPage.this, "Incorrect password.", Toast.LENGTH_SHORT).show();
                }

                else {

                    databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                            if (snapshot.hasChild(contact)) {
                                Toast.makeText(RegistrationPage.this, "Phone is already registered.", Toast.LENGTH_SHORT).show();
                            }

                            else {
                                databaseReference.child("users").child(contact).child("name").setValue(name);
                                databaseReference.child("users").child(contact).child("contact").setValue(email);
                                databaseReference.child("users").child(contact).child("password1").setValue(password1);

                                Toast.makeText(RegistrationPage.this, "Account registered successfully", Toast.LENGTH_SHORT).show();

                                Intent intent = new Intent(RegistrationPage.this, LoginPage.class);
                                //startActivity(intent);
                                //finish();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
        });


















    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}