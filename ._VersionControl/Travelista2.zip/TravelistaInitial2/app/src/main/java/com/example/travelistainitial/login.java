package com.example.travelistainitial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {

    EditText edtLogEmail, edtLogPass;
    Button btnSignIn;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtLogEmail = (EditText) findViewById(R.id.edtLogEmail);
        edtLogPass = (EditText) findViewById(R.id.edtLogPass);
        btnSignIn = (Button) findViewById(R.id.btnSignIn);
        DB = new DBHelper(this);

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = edtLogEmail.getText().toString();
                String pass = edtLogPass.getText().toString();

                if (email.equals("")||pass.equals(""))
                    Toast.makeText(login.this, "All fields are required!", Toast.LENGTH_SHORT).show();
                else{
                    Boolean checkuserpass = DB.checkusernamepassword(email, pass);
                        if(checkuserpass==true) {
                            Toast.makeText(login.this, "Sign In Successfully!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), Direction_Page.class);
                            startActivity(intent);
                        }else {
                            Toast.makeText(login.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                        }
                }

            }
        });
    }
}