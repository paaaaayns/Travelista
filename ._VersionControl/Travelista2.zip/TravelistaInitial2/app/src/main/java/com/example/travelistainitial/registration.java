package com.example.travelistainitial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class registration extends AppCompatActivity {

    EditText edtRegEmail, edtRegPass, edtRegRepass;
    Button btnSignUp;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        edtRegEmail = (EditText) findViewById(R.id.edtRegEmail);
        edtRegPass = (EditText) findViewById(R.id.edtRegPass);
        edtRegRepass = (EditText) findViewById(R.id.edtRegRepass);
        btnSignUp = (Button) findViewById(R.id.btnSignUp);
        DB = new DBHelper(this);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = edtRegEmail.getText().toString();
                String pass = edtRegPass.getText().toString();
                String repass = edtRegRepass.getText().toString();

                if (email.equals("")||pass.equals("")||repass.equals(""))
                    Toast.makeText(registration.this, "All fields are required!", Toast.LENGTH_SHORT).show();
                else {
                    if (pass.equals(repass)) {
                        Boolean checkemail = DB.checkusername(email);
                        if (checkemail==false){
                            Boolean insert = DB.insertData(email, pass);
                            if (insert==true){
                                Toast.makeText(registration.this, "Registered successfully!", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                Toast.makeText(registration.this, "Registration failed!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(registration.this, "User Account already exist! Please Sign-in", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(registration.this, "Password does not match!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}