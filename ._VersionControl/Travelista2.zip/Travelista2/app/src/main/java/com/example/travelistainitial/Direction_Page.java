package com.example.travelistainitial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Direction_Page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_direction_page);
    }
}